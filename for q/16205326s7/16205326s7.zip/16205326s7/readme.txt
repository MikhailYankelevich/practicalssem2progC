The compiler which was used is gcc mac compiler
